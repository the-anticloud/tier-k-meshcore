# Build & Test — K_MESHCORE

```bash
git clone https://github.com/meshcore-dev/MeshCore
cd k-meshcore
pip install -e .[dev]
pytest tests/
```

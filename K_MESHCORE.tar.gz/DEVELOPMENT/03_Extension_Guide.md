# Extension Guide — K_MESHCORE

To extend K_MESHCORE with AIOSS ledger:
1. Import `aioss_integration.py`
2. Call `log_call()` around key inference calls

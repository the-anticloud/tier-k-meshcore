# Environment Lab Results — K_MESHCORE

**Run:** 2026-09-30T19:03:55.522199+00:00

**OS:** Windows 10 | **Python:** 3.12.10

**CPU:** Intel64 Family 6 Model 60 Stepping 3, GenuineIntel (8 cores)

**RAM:** 23.91 GB | **Disk free:** 430.09 GB

**GPU:** Not available

**Bandit:** PASS (HIGH=0)

**Radon CC:** B

**Upstream files:** 904 total, 6 Python

**AIOSS Ledger:** SHA3-256 chain, 0 entries

_For GPU inference benchmarks, run: https://www.kaggle.com/code/loiskleinner/anticloud-real-benchmarks_
